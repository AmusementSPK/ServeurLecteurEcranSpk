sub init()
    m.video = m.top.FindNode("video")
    m.statusLabel = m.top.FindNode("statusLabel")
    m.detailLabel = m.top.FindNode("detailLabel")
    m.retryTimer = m.top.FindNode("retryTimer")

    m.video.ObserveField("state", "onVideoStateChanged")
    m.retryTimer.ObserveField("fire", "onRetryTimer")

    m.serverIp = ""
    m.serverPort = "8090"
    m.tvId = ""
    m.tvName = ""
    m.availableTvs = []
    m.dialog = invalid
    m.tvListTask = invalid

    loadServerEnv()
    m.top.SetFocus(true)
end sub


sub loadServerEnv()
    envText = ReadAsciiFile("pkg:/config/server.env")

    if envText = invalid or envText = ""
        m.serverIp = "10.10.0.135"
        m.serverPort = "8090"
        return
    end if

    lines = envText.Tokenize(Chr(10))

    for each rawLine in lines
        line = rawLine.Trim()

        if line <> "" and Left(line, 1) <> "#"
            equalsPos = Instr(1, line, "=")

            if equalsPos > 1
                key = UCase(Left(line, equalsPos - 1).Trim())
                value = Mid(line, equalsPos + 1).Trim()

                if key = "SERVER_IP"
                    m.serverIp = normalizeServerIp(value)
                else if key = "SERVER_PORT"
                    m.serverPort = value
                end if
            end if
        end if
    end for

    if m.serverIp = "" then m.serverIp = "10.10.0.135"
    if m.serverPort = "" then m.serverPort = "8090"
end sub


sub onConfigReady()
    if m.top.configLoaded <> true then return

    m.tvId = m.top.tvId.Trim()

    if m.tvId = ""
        showTvSelector()
    else
        startStream()
    end if
end sub


sub showTvSelector()
    m.retryTimer.control = "stop"
    m.video.control = "stop"
    m.video.visible = false

    m.statusLabel.visible = true
    m.statusLabel.text = "Chargement des televisions..."
    m.detailLabel.visible = true
    m.detailLabel.text = "Serveur : " + m.serverIp + ":" + m.serverPort

    m.availableTvs = []
    m.dialog = invalid

    task = CreateObject("roSGNode", "TvListTask")
    task.url = "http://" + m.serverIp + ":" + m.serverPort + "/api/roku/tvs"
    task.ObserveFieldScoped("result", "onTvListLoaded")
    task.ObserveFieldScoped("error", "onTvListError")

    m.tvListTask = task
    task.control = "RUN"
end sub


sub onTvListLoaded()
    if m.tvListTask = invalid then return

    result = m.tvListTask.result
    if result = invalid or result.televisions = invalid
        showTvListErrorDialog("Liste des televisions invalide.")
        return
    end if

    m.availableTvs = result.televisions

    if m.availableTvs.Count() = 0
        showTvListErrorDialog("Aucune television n'est configuree sur le serveur.")
        return
    end if

    buttons = []

    for each tv in m.availableTvs
        id = ""
        name = ""

        if tv.id <> invalid then id = tv.id.ToStr()
        if tv.name <> invalid then name = tv.name.ToStr().Trim()

        if name = "" then name = "TV " + id

        ' Le nom est prioritaire. L'ID reste visible pour le dépannage.
        buttons.Push(name + "  (TV " + id + ")")
    end for

    dlg = CreateObject("roSGNode", "StandardMessageDialog")
    dlg.title = "Choisir cette television"
    dlg.message = [
        "La liste vient directement du serveur SPK.",
        "Choisis le menu que cette Roku doit afficher."
    ]
    dlg.buttons = buttons
    dlg.ObserveFieldScoped("buttonSelected", "onTvSelected")

    m.dialog = dlg
    m.top.dialog = dlg
    dlg.SetFocus(true)
end sub


sub onTvListError()
    if m.tvListTask = invalid then return

    message = m.tvListTask.error
    if message = invalid or message = "" then return

    showTvListErrorDialog(message)
end sub


sub showTvListErrorDialog(message as String)
    dlg = CreateObject("roSGNode", "StandardMessageDialog")
    dlg.title = "Serveur SPK inaccessible"
    dlg.message = [
        message,
        "Serveur : " + m.serverIp + ":" + m.serverPort
    ]
    dlg.buttons = ["Reessayer"]
    dlg.ObserveFieldScoped("buttonSelected", "onRetryTvList")

    m.dialog = dlg
    m.top.dialog = dlg
    dlg.SetFocus(true)
end sub


sub onRetryTvList()
    m.top.dialog = invalid
    m.dialog = invalid
    showTvSelector()
end sub


sub onTvSelected()
    if m.dialog = invalid then return

    selectedIndex = m.dialog.buttonSelected
    if selectedIndex < 0 then return
    if selectedIndex >= m.availableTvs.Count() then return

    selectedTv = m.availableTvs[selectedIndex]

    m.tvId = selectedTv.id.ToStr()
    m.tvName = ""
    if selectedTv.name <> invalid then m.tvName = selectedTv.name.ToStr().Trim()
    if m.tvName = "" then m.tvName = "TV " + m.tvId

    m.top.dialog = invalid
    m.dialog = invalid

    m.top.saveTvConfig = {
        tvId: m.tvId
    }

    startStream()
end sub


function normalizeServerIp(value as String) as String
    result = value.Trim()

    if Left(LCase(result), 7) = "http://" then result = Mid(result, 8)
    if Left(LCase(result), 8) = "https://" then result = Mid(result, 9)

    slashPos = Instr(1, result, "/")
    if slashPos > 0 then result = Left(result, slashPos - 1)

    colonPos = Instr(1, result, ":")
    if colonPos > 0 then result = Left(result, colonPos - 1)

    return result.Trim()
end function


sub startStream()
    if m.tvId = ""
        showTvSelector()
        return
    end if

    m.retryTimer.control = "stop"
    m.video.control = "stop"

    url = "http://" + m.serverIp + ":" + m.serverPort + "/hls/tv" + m.tvId + "/index.m3u8"

    content = CreateObject("roSGNode", "ContentNode")
    content.url = url
    content.streamFormat = "hls"

    if m.tvName <> ""
        content.title = m.tvName
    else
        content.title = "SPK Menu TV " + m.tvId
    end if

    m.video.content = content

    ' IMPORTANT : la television ne boucle jamais la video.
    ' Le serveur FFmpeg fournit le flux HLS LIVE continu.
    m.video.loop = false
    m.video.enableUI = false
    m.video.disableScreenSaver = true
    m.video.visible = true

    m.statusLabel.visible = true
    if m.tvName <> ""
        m.statusLabel.text = "SPK - " + m.tvName
    else
        m.statusLabel.text = "SPK HLS v1.6 - TV " + m.tvId
    end if

    m.detailLabel.visible = true
    m.detailLabel.text = "Connexion TV " + m.tvId + "   |   * = changer de menu"

    m.top.SetFocus(true)
    m.video.control = "play"
end sub


sub onVideoStateChanged()
    state = m.video.state

    if state = "playing"
        m.statusLabel.visible = false
        m.detailLabel.visible = false

    else if state = "buffering"
        m.statusLabel.visible = true
        if m.tvName <> ""
            m.statusLabel.text = "Chargement " + m.tvName + "..."
        else
            m.statusLabel.text = "Chargement TV " + m.tvId + "..."
        end if
        m.detailLabel.visible = false

    else if state = "error"
        m.video.visible = false
        m.statusLabel.visible = true
        m.statusLabel.text = "Serveur video inaccessible"
        m.detailLabel.visible = true
        m.detailLabel.text = m.serverIp + ":" + m.serverPort + "   |   Nouvel essai dans 5 secondes"
        m.retryTimer.control = "start"

    else if state = "finished"
        ' Un flux HLS live normal ne doit pas se terminer.
        m.video.visible = false
        m.statusLabel.visible = true
        m.statusLabel.text = "Flux serveur interrompu"
        m.detailLabel.visible = true
        m.detailLabel.text = "Reconnexion dans 5 secondes"
        m.retryTimer.control = "start"
    end if
end sub


sub onRetryTimer()
    startStream()
end sub


function onKeyEvent(key as String, press as Boolean) as Boolean
    if press <> true then return false

    if key = "options"
        showTvSelector()
        return true
    end if

    if key = "back"
        return true
    end if

    return false
end function
