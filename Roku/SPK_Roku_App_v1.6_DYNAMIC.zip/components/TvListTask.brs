sub init()
    m.top.functionName = "runTask"
end sub

sub runTask()
    m.top.error = ""

    url = m.top.url.Trim()
    if url = ""
        m.top.error = "Adresse du serveur manquante."
        return
    end if

    transfer = CreateObject("roUrlTransfer")
    transfer.SetUrl(url)
    transfer.SetRequest("GET")
    transfer.AddHeader("Accept", "application/json")
    transfer.AddHeader("Cache-Control", "no-cache")

    response = transfer.GetToString()

    if response = invalid or response = ""
        m.top.error = "Le serveur ne repond pas."
        return
    end if

    parsed = ParseJson(response)

    if parsed = invalid
        m.top.error = "Reponse serveur invalide."
        return
    end if

    if parsed.televisions = invalid
        m.top.error = "Liste des televisions absente."
        return
    end if

    m.top.result = parsed
end sub
