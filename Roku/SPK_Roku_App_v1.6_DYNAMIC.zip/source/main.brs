sub Main()
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)

    scene = screen.CreateScene("MainScene")
    scene.ObserveField("saveTvConfig", port)

    screen.Show()

    config = LoadTvConfig()
    scene.tvId = config.tvId
    scene.configLoaded = true

    while true
        msg = Wait(0, port)
        msgType = Type(msg)

        if msgType = "roSGScreenEvent"
            if msg.IsScreenClosed() then return

        else if msgType = "roSGNodeEvent"
            if msg.GetField() = "saveTvConfig"
                data = msg.GetData()
                if data <> invalid
                    SaveTvConfig(data)
                end if
            end if
        end if
    end while
end sub


function LoadTvConfig() as Object
    result = {
        tvId: ""
    }

    section = CreateObject("roRegistrySection", "SPKStreaming")
    if section <> invalid
        if section.Exists("tvId")
            result.tvId = section.Read("tvId")
        end if
    end if

    return result
end function


sub SaveTvConfig(data as Object)
    if data = invalid then return

    section = CreateObject("roRegistrySection", "SPKStreaming")
    if section = invalid then return

    if data.tvId <> invalid
        section.Write("tvId", data.tvId.ToStr())
    end if

    section.Flush()
end sub
